# Domain Model Overview

The `DreamTeam.Wod.EmployeeService.DomainModel` project defines the EF Core entity set for the service. Entities are grouped into thematic areas described below.

## Employees & Assignments

- `Employee`: Root aggregate representing a person employed by the company. Stores identifiers (external/person/domain), employment status, managers, mentor, seniority, title role, contact information and related collections (`EmploymentPeriods`, `WageRatePeriods`, `Roles`, `Workplaces`, `CurrentLocation`). Implements `Clone()` to support snapshotting without mutating the original instance.
- `EmploymentPeriod`: Captures start/end dates for employment stretches and links to `EmploymentType`.
- `WageRatePeriod`: Records wage rate changes across time.
- `EmployeeWorkplace` and `Workplace`: Describe physical workplaces and scheme images.
- `EmployeeCurrentLocation`, `EmployeeCurrentLocationChange`: Track relocation of employees between offices/countries.
- `EmployeeOrganizationChange`, `EmployeeUnitHistory`: Keep historical unit/org assignments aligned with organisational charts.

## Requests & Lifecycle Events

- `EmploymentRequest` / `ExternalEmploymentRequest`: Represent onboarding requests received from external systems; include metadata on initiator, target unit, employment type and timestamps.
- `DismissalRequest` / `ExternalDismissalRequest`: Mirror employment requests for offboarding flows, including dismissal reasons (`DismissalRequestType`, `DeactivationReason`).
- `CompensationInfo` and `CompensationInfoDetails*`: Store salary package information associated with employment requests.

## Internships

- `Internship`: Tracks internship periods, mentors, employment outcomes and additional state transitions (close reasons, conversion into employment).
- `InternshipCloseReason`: Enumeration of reasons for closing internships.
- `UnitInternshipsCount`: Aggregated counts per organisational unit for reporting.

## Relocation Programme

- `RelocationPlan`: Core aggregate describing relocation requests, target countries/offices, status, key dates and related changes. Supports nested collections such as `RelocationPlanChanges`, `RelocationPlanSteps` and visa progress logs.
- `RelocationPlanStatus`, `RelocationPlanState`, `RelocationPlanChangeType`: Enumerations capturing the state machine of relocation plans.
- `RelocationPlanChange`, `RelocationPlanStep`, `RelocationPlanTrpState`: Track adjustments and step execution for relocation processes.
- `CountryRelocationStep`: Defines country-specific workflows and requirements.
- `RelocationApprover`, `RelocationApproverAssignment`, `RelocationApproverOrder`: Manage approver hierarchies and routing for relocation approvals.

## Roles & Seniority

- `Role`, `EmployeeRole`: Attach organisational roles to employees.
- `TitleRole`, `RoleConfiguration*`: Map title roles to organisational units and configure dynamic access checks.
- `Seniority`: Represents seniority levels for employees.

## Synchronisation & Logging

- `SyncLog`, `StudentLabSyncLog`: Persist metadata about synchronisation runs for troubleshooting and auditing.
- `EmployeeSnapshot`, `EmployeeSnapshotLog`: Store daily snapshots of employee state and log recalculation triggers.

## Supporting Types

- `CurrentLocation`, `Country`, `OrganizationId` (via string fields) and other supporting value objects provide additional context for the aggregates above.
- Enumerations such as `EmploymentType` and `RelocationCaseStatus` express domain-specific states used across services.

When extending the domain model, update the corresponding mappings in `EmployeeServiceDbContext` and ensure any new reference data is seeded through `EmployeeServiceDatabaseInitializer`.

