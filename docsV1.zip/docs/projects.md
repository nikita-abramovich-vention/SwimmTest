# Project Reference

## DreamTeam.Wod.EmployeeService

- **Entry point**: `Program.cs` configures the .NET Generic Host, logging, dependency injection registrations and Hangfire-based background jobs.
- **Hosted service**: `EmployeeHostedService.cs` bridges the foundation microservice with RabbitMQ messaging via `ICommunicationService` and `IRabbitMqMessageTransportFactory`.
- **Configuration options**: `ConfigurationOptions/` contains strongly typed options for message transport and synchronisation services that are bound from `appsettings*.json` files.
- **Service configuration wrappers**: `Configurations/` adapts configuration sections into the interfaces expected by foundation services (for example `StudentLabSyncServiceConfiguration`).
- **Environment files**: `appsettings.json`, `appsettings.Development.json`, `appsettings.Localhost.json` and `appsettings.Production.json` provide defaults for different deployments.

## DreamTeam.Wod.EmployeeService.DomainModel

- **Employee lifecycle**: Entities such as `Employee`, `EmploymentPeriod`, `WageRatePeriod`, `EmployeeWorkplace` and `EmployeeCurrentLocation` capture staffing and assignment history.
- **Requests**: `EmploymentRequest`, `DismissalRequest`, `ExternalEmploymentRequest` model onboarding/offboarding workflows and integration payloads.
- **Compensation**: `CompensationInfo` and related detail classes store salary breakdowns.
- **Relocation**: `RelocationPlan`, `RelocationPlanStatus`, `RelocationPlanStep`, `CountryRelocationStep` and approver entities represent relocation programmes.
- **Roles and hierarchy**: `Role`, `RoleConfiguration*`, `TitleRole`, `Seniority` reflect organisational structure and authorisations.
- **Internships**: `Internship`, `InternshipCloseReason`, `UnitInternshipsCount` support internship tracking and reporting.
- **Sync logging**: `SyncLog`, `StudentLabSyncLog` keep track of synchronisation attempts with external systems.

Entities are kept as light POCOs to support EF Core mapping in the repositories project.

## DreamTeam.Wod.EmployeeService.Foundation

- **Employees**: Services and specifications around employee CRUD, snapshots (`EmployeeSnapshotService`), employment periods and wage rates.
- **Employment requests**: Import, merge and persistence logic for employment request pipelines including `EmploymentRequestSyncService`.
- **Dismissal requests**: Mirror the employment request flow with dedicated specs and sync services.
- **Employee unit history**: Track organisational movements and expose sync services for external feeds.
- **Internships**: Manage internship lifecycle, pagination helpers and Student Lab integration.
- **Relocation plans**: `RelocationPlanService` plus helpers handle plan creation, approvals, status changes and synchronisation of relocation steps.
- **Relocation approvers**: Manage approver assignments, ordering and lookups per country.
- **Active Directory**: `ActiveDirectoryService` and supporting interfaces encapsulate domain authentication and username generation.
- **Providers**: Country, office, organisation and unit providers aggregate data from repositories and external services for reuse across features.
- **Microservice surface**: `IEmployeeMicroservice` defines the comprehensive contract exposed via messaging.
- **Integration adapters**: `StudentLabSync`, `WspSync`, `EmploymentRequestSync`, `DismissalRequestSync`, `EmployeeUnitHistorySync` and `Microservices` directories encapsulate communication with neighbour services and shared DTO mapping.

## DreamTeam.Wod.EmployeeService.Repositories

- **DbContext**: `EmployeeServiceDbContext` declares all EF Core entity sets and configuration using fluent API mapping.
- **Database initialization**: `EmployeeServiceDatabaseInitializer` applies migrations and seeds static reference dictionaries (countries, offices, relocation metadata, etc.).
- **Unit of work**: `EmployeeServiceUnitOfWork` and the accompanying factory expose transactional access for foundation services.
- **Design time support**: `EmployeeServiceDesignTimeDbContextFactory` enables `dotnet ef` tooling.
- **Migrations**: `Migrations/` stores generated migration classes and snapshots.

The repository layer relies on SQL Server and integrates with the shared `DreamTeam.Repositories` helpers for migration orchestration.

