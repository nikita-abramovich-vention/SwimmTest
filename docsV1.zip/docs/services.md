# Domain Services

## Employee Lifecycle

- `Employees/EmployeeService.cs` orchestrates employee creation and updates, enforcing domain invariants through specifications (`EmployeeSpecification`, `EmployeeSnapshotSpecification`). It raises observable events (`EmployeeCreating`, `EmployeeUpdated`, etc.) and coordinates persistence through `IEmployeeServiceUnitOfWork`.
- `Employees/EmployeeSnapshotService.cs` materialises historical per-day snapshots by combining wage rates, roles, unit assignments and locations. It is used by background jobs to recalculate snapshots on schedule (`RecalculateEmployeeSnapshotsStatus`).
- `Employees/EmploymentPeriodService.cs` and `Employees/WageRatePeriodService.cs` supply helpers for validating overlapping periods and ensuring chronological integrity.
- `Employees/EmployeeLocationProvider.cs` resolves the current office/organisation context for an employee, used by downstream integrations.

## Requests & Synchronisation Pipelines

- `EmploymentRequests/EmploymentRequestService.cs` manages onboarding requests, mapping external payloads into domain entities and resolving duplicates via `EmploymentRequestSpecification`.
- `EmploymentRequests/EmploymentRequestSyncService.cs` fetches employment requests from external APIs, converts them into domain entities using `IEmployeeServiceUnitOfWork`, and reconciles status back to the upstream system.
- `DismissalRequests/DismissalRequestService.cs` mirrors the onboarding flow for termination records. Its sync service (`DismissalRequestSyncService.cs`) performs periodic imports and updates the upstream via DTO mappers.
- `EmployeeUnitHistory/EmployeeUnitHistoryService.cs` materialises unit and organisation changes; the associated sync service keeps the data aligned with HR master records.

Each sync service receives configuration objects from the host project (`Configurations/*SyncServiceConfiguration.cs`) that wrap `IOptionsMonitor<T>` and expose scheduling, batch size and endpoint settings.

## Internships & Student Lab

- `Internships/InternshipService` (implemented within `EmployeeService`) together with `StudentLabSync` components manages internship lifecycle, including automatic closure based on `EmployeeServiceOptions.AutomaticallyCloseInternship*` values.
- `StudentLabSync/StudentLabSyncService.cs` coordinates the polling of Student Lab, mapping records via `StudentLabService.cs` into persistence through the repositories layer. Downloaded batches are tracked with `StudentLabSyncLog` entities in the domain model.

## Relocation Programme

- `RelocationPlans/RelocationPlanService.cs` encapsulates creation, approval, status transitions, visa progress tracking and closure of relocation plans. It relies on `RelocationPlanStatus`, `RelocationPlanChange` and step definitions from the domain model.
- `RelocationApprovers/RelocationApproverService.cs` manages approver hierarchies, primary approver retrieval and validation of assignments.
- `Countries/CountryProvider.cs` and `Offices/OfficeProvider.cs` supply metadata required for relocation moves and location lookups.

## External Systems

- `Microservices/` contains adapters for interacting with DreamTeam shared services (SMG, Department Service, Profile Service, Time Tracking). For example, `SmgIdProvider` maps SMG identifiers to employees and `SmgProfileMapper` converts external profiles into internal representations.
- `ActiveDirectory/ActiveDirectoryService.cs` signs requests and validates domain names using `ActiveDirectoryAuthenticationOptions` configured in the host.
- `WspSync/WspSyncService.cs` synchronises workplace scheme images and metadata, exposing queries through `IEmployeeMicroservice`.

## Surface Area (Microservice Contract)

`IEmployeeMicroservice` exposes the aggregated read/write operations used by consumers over RabbitMQ messaging. Its implementation (wiring occurs in the foundation layer) combines the services above to offer:

- Employee queries (by id, person id, role, unit, snapshots).
- Internship management (CRUD, pagination, manager assignments).
- Relocation plan lifecycle (creation, confirmation, closure, approver management).
- Dismissal and employment request management.
- Lookup endpoints (countries, offices, roles, wage rates) and document retrieval (workplace scheme images).

## Background Jobs

Recurring jobs (registered via `AddBackgroundJobs` in the host) call into the services above to:

- Refresh snapshots (`IEmployeeSnapshotService`).
- Close internships automatically based on configuration.
- Sync relocation plans and unit history.
- Pull dismissal/employment requests and push updates back to source systems.

Jobs use SQL Server-backed storage and honour cron expressions defined in the options classes. When extending background work, update both the Hangfire registration and corresponding options so they can be tuned per environment.

