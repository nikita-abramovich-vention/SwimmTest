# DreamTeam WOD Employee Service

## Overview

DreamTeam WOD Employee Service is a background microservice that exposes employee data and orchestrates synchronisation with external systems inside the DreamTeam ecosystem. The host (`DreamTeam.Wod.EmployeeService/Program.cs`) wires logging, configuration and dependency injection, then runs `EmployeeHostedService` which bridges the service with RabbitMQ messaging and the shared microservice communication layer.

The service consolidates employee master data, internships, relocation plans, dismissal requests and synchronisation flows with surrounding systems such as Student Lab, WSP and Active Directory. Business logic lives in the `DreamTeam.Wod.EmployeeService.Foundation` project, the storage layer is implemented in `DreamTeam.Wod.EmployeeService.Repositories`, and entity definitions reside in `DreamTeam.Wod.EmployeeService.DomainModel`.

## Solution Layout

- `DreamTeam.Wod.EmployeeService` - executable host that sets up logging (`Serilog` via `SerilogOptions`), configures options such as `EmployeeServiceOptions`, registers services and hosted background jobs.
- `DreamTeam.Wod.EmployeeService.DomainModel` - POCO entities representing employees, internships, relocation plans, dismissal requests, compensation structures and related supporting types.
- `DreamTeam.Wod.EmployeeService.Foundation` - domain services grouped by feature area (employees, employment requests, dismissals, relocation, synchronisation providers, etc.), plus the microservice contract `IEmployeeMicroservice` that the hosting layer exposes.
- `DreamTeam.Wod.EmployeeService.Repositories` - Entity Framework Core infrastructure (`EmployeeServiceDbContext`, unit of work, database initializer) and migrations.

Supporting configuration lives under `appsettings.{Environment}.json` in the host project, with explicit options classes under `ConfigurationOptions/` and synchronisation configuration adapters under `Configurations/`.

## Runtime Architecture

- **Host builder**: `Program.CreateHostBuilder` sets up default .NET Generic Host semantics, clears default loggers and replaces them with Serilog console logging configured from `Logging` sections.
- **Hosted service**: `EmployeeHostedService` initialises messaging infrastructure via `IRabbitMqMessageTransportFactory` and runs the microservice implementation through `ICommunicationService`.
- **Messaging**: RabbitMQ transport settings are bound through `RabbitMqMessageTransportOptions`, enabling the service to publish/consume messages for integration scenarios.
- **Background jobs**: `services.AddBackgroundJobs` registers Hangfire-style background processing backed by SQL Server storage, used for recurring synchronisation and maintenance tasks configured through options cron expressions.
- **Initialization**: At startup the service resolves `IDatabaseInitializer<EmployeeServiceDbContext>` to apply migrations/seed data and initialises shared contexts (`LoggerContext`, `JsonSerializerContext`).

## Data Access

`DreamTeam.Wod.EmployeeService.Repositories` provides the EF Core model. `EmployeeServiceDbContext` exposes sets for employees, internships, relocation plans, employment periods, wage rates and supporting configuration entities. The unit-of-work wrapper (`EmployeeServiceUnitOfWork` and factory) coordinates repository access inside the higher-level services, while `EmployeeServiceDatabaseInitializer` applies migrations and seeds reference data such as countries, roles, offices and relocation step definitions.

## Business Services

Foundation services are organised per concern:

- **Employees**: `EmployeeService`, `EmployeeSnapshotService` and helpers manage employee lifecycle, snapshots, roles and wage rates.
- **Employment / Dismissal requests**: Dedicated services handle import, validation and persistence of onboarding/offboarding requests with sync counterparts that interface with external systems.
- **Unit history / Locations**: Services manage past and current unit assignments and physical locations.
- **Relocation**: `RelocationPlanService` orchestrates relocation plan state transitions, approvers and synchronisation of relocation steps.
- **Integrations**: `StudentLabSyncService`, `WspSyncService`, `EmploymentRequestSyncService`, `DismissalRequestSyncService` and `EmployeeUnitHistorySyncService` fetch data from neighbouring systems and reconcile it with the local store.
- **Active Directory & Identity**: `ActiveDirectoryService` coordinates authentication and domain name validation when provisioning staff.

The public-facing contract is exposed through `IEmployeeMicroservice`, which aggregates read/write endpoints for employees, internships, relocation plans, dismissal requests and related lookup data contracts.

## Configuration

Key option classes:

- `EmployeeServiceOptions` - message queue name, automation intervals (internship closure, relocation plan cron) and behavioural flags.
- `StudentLabSyncServiceOptions`, `WspSyncServiceOptions`, `EmploymentRequestSyncServiceOptions`, `DismissalRequestSyncServiceOptions`, `EmployeeUnitHistorySyncServiceOptions` - connectivity and scheduling for each synchronisation pipeline.
- `ActiveDirectoryAuthenticationOptions` (from the foundation layer) - domain credentials for Active Directory lookups.

Configuration values are bound from the matching sections in `appsettings.json` or environment-specific overrides (`appsettings.Localhost.json`, etc.).

## Running the Service Locally

1. Ensure SQL Server and RabbitMQ endpoints referenced in `appsettings.Localhost.json` are reachable.
2. Restore dependencies: `dotnet restore WodEmployeeService.sln`.
3. Apply migrations (if needed): `dotnet ef database update --project DreamTeam.Wod.EmployeeService.Repositories`.
4. Run the host: `dotnet run --project DreamTeam.Wod.EmployeeService`.
5. Monitor logs for successful initialisation of `EmployeeHostedService` and background jobs.

## External Dependencies

- DreamTeam shared libraries: logging (`DreamTeam.Logging`), repositories (`DreamTeam.Repositories`), microservice framework (`DreamTeam.Microservices.*`).
- RabbitMQ for messaging transport.
- SQL Server for persistence and background job storage.
- External microservices for Student Lab, WSP, SMG profile, department/unit data and Active Directory.

## Adding Documentation

This documentation replaces the automated `codex run doc-writer` output which is restricted in this environment. Update or extend these Markdown files when new feature areas or domain entities are introduced.
