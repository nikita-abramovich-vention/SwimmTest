# Domain Model Documentation

Документация сгенерирована локальным скриптом на основе исходников `DreamTeam.Wod.EmployeeService.DomainModel` (без обращения к удалённому агенту).

## CompensationInfo

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/CompensationInfo.cs`
- Свойства:
  - `Id` (`int`)
  - `RelocationPlanId` (`int`): FK на `RelocationPlan`
  - `RelocationPlan` (`RelocationPlan`): связь с `RelocationPlan`
  - `Total` (`float`)
  - `Currency` (`string`)
  - `Details` (`CompensationInfoDetails`): связь с `CompensationInfoDetails`
  - `PreviousCompensation` (`PreviousCompensationInfo`): связь с `PreviousCompensationInfo`
  - `PaidInAdvance` (`bool`)

## CompensationInfoDetails

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/CompensationInfoDetails.cs`
- Свойства:
  - `Child` (`CompensationInfoDetailsItem`): связь с `CompensationInfoDetailsItem`
  - `Spouse` (`CompensationInfoDetailsItem`): связь с `CompensationInfoDetailsItem`
  - `Employee` (`CompensationInfoDetailsItem`): связь с `CompensationInfoDetailsItem`

## CompensationInfoDetailsItem

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/CompensationInfoDetailsItem.cs`
- Свойства:
  - `Amount` (`float`)
  - `Enabled` (`bool`)
  - `NumberOfPeople` (`int`)

## CountryRelocationStep

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/CountryRelocationStep.cs`
- Свойства:
  - `CountryId` (`string`)
  - `StepId` (`RelocationStepId`): связь с `RelocationStepId`
  - `DurationInDays` (`int?`): опционально
  - `Order` (`int`)

## CurrentLocation

- Наследование: IHasCreateInfo
- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/CurrentLocation.cs`
- Константы:
  - `NameMaxLength` (`int`) = 200
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `Name` (`string`): максимум 200 символов
  - `IsCustom` (`bool`)
  - `HasCompanyOffice` (`bool`)
  - `IsRelocationDisabled` (`bool`)
  - `CountryId` (`string`)
  - `CreatedBy` (`string`)
  - `CreationDate` (`DateTime`)

## DismissalRequest

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/DismissalRequest.cs`
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `IsActive` (`bool`)
  - `SourceDismissalRequestId` (`int?`): опционально
  - `SourceDismissalRequest` (`ExternalDismissalRequest`): связь с `ExternalDismissalRequest`
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `DismissalDate` (`DateOnly`)
  - `Type` (`DismissalRequestType`): связь с `DismissalRequestType`
  - `CloseDate` (`DateTime?`): опционально
  - `CreationDate` (`DateTime`)
  - `UpdateDate` (`DateTime?`): опционально

## Employee

- Наследование: IHasUpdateInfo
- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/Employee.cs`
- Константы:
  - `DomainNameMaxLength` (`int`) = 200
  - `EmailMaxLength` (`int`) = 254
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `PersonId` (`string`)
  - `IsActive` (`bool`)
  - `IsDismissed` (`bool`)
  - `DomainName` (`string`): максимум 200 символов
  - `Email` (`string`): максимум 254 символов
  - `EmploymentPeriods` (`ICollection<EmploymentPeriod>`): коллекция `EmploymentPeriod`; связь с `EmploymentPeriod` (многие)
  - `WageRatePeriods` (`ICollection<WageRatePeriod>`): коллекция `WageRatePeriod`; связь с `WageRatePeriod` (многие)
  - `UnitId` (`string`)
  - `ResponsibleHrManagerId` (`int?`): опционально
  - `ResponsibleHrManager` (`Employee`)
  - `MentorId` (`int?`): опционально
  - `Mentor` (`Employee`)
  - `EmploymentDate` (`DateOnly`)
  - `DismissalDate` (`DateOnly?`): опционально
  - `SeniorityId` (`int?`): опционально; FK на `Seniority`
  - `Seniority` (`Seniority`): связь с `Seniority`
  - `TitleRoleId` (`int?`): опционально; FK на `TitleRole`
  - `TitleRole` (`TitleRole`): связь с `TitleRole`
  - `Roles` (`ICollection<EmployeeRole>`): коллекция `EmployeeRole`; связь с `EmployeeRole` (многие)
  - `CountryId` (`string`)
  - `OrganizationId` (`string`)
  - `EmploymentOfficeId` (`string`)
  - `CurrentLocationId` (`int?`): опционально; FK на `CurrentLocation`
  - `CurrentLocation` (`EmployeeCurrentLocation`): связь с `EmployeeCurrentLocation`
  - `DeactivationReason` (`DeactivationReason?`): опционально; связь с `DeactivationReason`
  - `Workplaces` (`ICollection<EmployeeWorkplace>`): коллекция `EmployeeWorkplace`; связь с `EmployeeWorkplace` (многие)
  - `EmploymentType` (`EmploymentType`): связь с `EmploymentType`
  - `CreationDate` (`DateTime`)
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime?`): опционально

## EmployeeCurrentLocation

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmployeeCurrentLocation.cs`
- Свойства:
  - `Id` (`int`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `LocationId` (`int`)
  - `Location` (`CurrentLocation`): связь с `CurrentLocation`
  - `ChangedBy` (`string`)
  - `ChangeDate` (`DateTime`)
  - `SinceDate` (`DateOnly`)
  - `UntilDate` (`DateOnly?`): опционально

## EmployeeCurrentLocationChange

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmployeeCurrentLocationChange.cs`
- Свойства:
  - `Id` (`int`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `PreviousLocationId` (`int?`): опционально
  - `PreviousLocation` (`CurrentLocation`): связь с `CurrentLocation`
  - `NewLocationId` (`int?`): опционально
  - `NewLocation` (`CurrentLocation`): связь с `CurrentLocation`
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime`)

## EmployeeOrganizationChange

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmployeeOrganizationChange.cs`
- Свойства:
  - `Id` (`int`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `PreviousOrganizationId` (`string`)
  - `NewOrganizationId` (`string`)
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime`)

## EmployeeRole

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmployeeRole.cs`
- Свойства:
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `RoleId` (`int`): FK на `Role`
  - `Role` (`Role`): связь с `Role`

## EmployeeSnapshot

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmployeeSnapshot.cs`
- Свойства:
  - `Id` (`int`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `FromDate` (`DateOnly`)
  - `ToDate` (`DateOnly`)
  - `IsActive` (`bool`)
  - `SeniorityId` (`int?`): опционально; FK на `Seniority`
  - `Seniority` (`Seniority`): связь с `Seniority`
  - `TitleRoleId` (`int?`): опционально; FK на `TitleRole`
  - `TitleRole` (`TitleRole`): связь с `TitleRole`
  - `CountryId` (`string`)
  - `OrganizationId` (`string`)
  - `UnitId` (`string`)
  - `EmploymentType` (`EmploymentType`): связь с `EmploymentType`

## EmployeeSnapshotLog

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmployeeSnapshotLog.cs`
- Свойства:
  - `Id` (`int`)
  - `Date` (`DateTime`)
  - `IsSuccessful` (`bool`)

## EmployeeUnitHistory

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmployeeUnitHistory.cs`
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `UnitId` (`string`)
  - `StartDate` (`DateOnly`)
  - `EndDate` (`DateOnly?`): опционально
  - `CreationDate` (`DateTime`)
  - `UpdateDate` (`DateTime?`): опционально
  - `ExternalEmployeeUnitHistory` (`ExternalEmployeeUnitHistory`): связь с `ExternalEmployeeUnitHistory`

## EmployeeWorkplace

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmployeeWorkplace.cs`
- Свойства:
  - `Id` (`int`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `WorkplaceId` (`int`): FK на `Workplace`
  - `Workplace` (`Workplace`): связь с `Workplace`
  - `CreationDate` (`DateTime`)
  - `ExternalEmployeeWorkplace` (`ExternalEmployeeWorkplace`): связь с `ExternalEmployeeWorkplace`

## EmploymentPeriod

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmploymentPeriod.cs`
- Свойства:
  - `Id` (`int`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `StartDate` (`DateOnly`)
  - `EndDate` (`DateOnly?`): опционально
  - `OrganizationId` (`string`)
  - `IsInternship` (`bool`)

## EmploymentRequest

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmploymentRequest.cs`
- Константы:
  - `FirstNameLastNameMaxLength` (`int`) = 200
  - `LocationMaxLength` (`int`) = 200
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `SourceId` (`int`)
  - `SourceEmploymentRequest` (`ExternalEmploymentRequest`): связь с `ExternalEmploymentRequest`
  - `EmployeeId` (`int?`): опционально; FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `FirstName` (`string`)
  - `LastName` (`string`)
  - `UnitId` (`string`)
  - `Location` (`string`): максимум 200 символов
  - `CountryId` (`string`)
  - `OrganizationId` (`string`)
  - `EmploymentDate` (`DateOnly`)
  - `CreationDate` (`DateTime`)
  - `UpdateDate` (`DateTime?`): опционально

## ExternalDismissalRequest

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/ExternalDismissalRequest.cs`
- Константы:
  - `DismissalSpecificIdMaxLength` (`int`) = 200
- Свойства:
  - `Id` (`int`)
  - `SourceId` (`int`)
  - `IsActive` (`bool`)
  - `SourceEmployeeId` (`string`)
  - `DismissalDate` (`DateOnly`)
  - `SourceCreationDate` (`DateTime`)
  - `CloseDate` (`DateTime?`): опционально
  - `DismissalSpecificId` (`string`): максимум 200 символов
  - `CreationDate` (`DateTime`)
  - `UpdateDate` (`DateTime?`): опционально

## ExternalEmployeeUnitHistory

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/ExternalEmployeeUnitHistory.cs`
- Свойства:
  - `Id` (`int`)
  - `SourceEmployeeId` (`string`)
  - `SourceUnitId` (`string`)
  - `StartDate` (`DateOnly`)
  - `EndDate` (`DateOnly?`): опционально
  - `EmployeeUnitHistoryId` (`int?`): опционально; FK на `EmployeeUnitHistory`
  - `EmployeeUnitHistory` (`EmployeeUnitHistory`): связь с `EmployeeUnitHistory`
  - `CreationDate` (`DateTime`)
  - `UpdateDate` (`DateTime?`): опционально

## ExternalEmployeeWorkplace

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/ExternalEmployeeWorkplace.cs`
- Свойства:
  - `Id` (`int`)
  - `SourceEmployeeId` (`string`)
  - `SourceWorkplaceId` (`string`)
  - `CreationDate` (`DateTime`)
  - `EmployeeWorkplaceId` (`int?`): опционально; FK на `EmployeeWorkplace`
  - `EmployeeWorkplace` (`EmployeeWorkplace`): связь с `EmployeeWorkplace`

## ExternalEmploymentRequest

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/ExternalEmploymentRequest.cs`
- Константы:
  - `StatusNameMaxLength` (`int`) = 50
  - `FirstNameLastNameMaxLength` (`int`) = 200
  - `LocationMaxLength` (`int`) = 200
  - `TypeMaxLength` (`int`) = 50
- Свойства:
  - `Id` (`int`)
  - `SourceId` (`int`)
  - `Type` (`string`): максимум 50 символов
  - `StatusId` (`int`)
  - `StatusName` (`string`): максимум 50 символов
  - `FirstName` (`string`)
  - `LastName` (`string`)
  - `UnitId` (`string`)
  - `LocationId` (`int`)
  - `Location` (`string`): максимум 200 символов
  - `OrganizationId` (`string`)
  - `EmploymentDate` (`DateOnly`)
  - `CreationDate` (`DateTime`)
  - `UpdateDate` (`DateTime?`): опционально
  - `CloseDate` (`DateTime?`): опционально

## ExternalWorkplace

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/ExternalWorkplace.cs`
- Константы:
  - `NameMaxLength` (`int`) = 200
- Свойства:
  - `Id` (`int`)
  - `SourceId` (`string`)
  - `Name` (`string`): максимум 200 символов
  - `FullName` (`string`)
  - `SchemeUrl` (`string`)
  - `OfficeSourceId` (`string`)
  - `CreationDate` (`DateTime`)
  - `UpdateDate` (`DateTime?`): опционально
  - `Workplace` (`Workplace`): связь с `Workplace`

## Internship

- Наследование: IHasCreateUpdateInfo
- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/Internship.cs`
- Константы:
  - `DomainNameMaxLength` (`int`) = 200
  - `DomainNameRegex` (`string`) = "[A-z]+\\.[A-z]+"
  - `FirstNameLastNameMaxLength` (`int`) = 200
  - `SkypeMaxLength` (`int`) = 256
  - `PhoneMaxLength` (`int`) = 64
  - `EmailMaxLength` (`int`) = 254
  - `TelegramMaxLength` (`int`) = 32
  - `LocationMaxLength` (`int`) = 100
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `PersonId` (`string`)
  - `IsActive` (`bool`)
  - `FirstName` (`string`)
  - `LastName` (`string`)
  - `FirstNameLocal` (`string`)
  - `LastNameLocal` (`string`)
  - `PhotoId` (`string`)
  - `Skype` (`string`): максимум 256 символов
  - `Telegram` (`string`): максимум 32 символов
  - `Phone` (`string`): максимум 64 символов
  - `Email` (`string`): максимум 254 символов
  - `DomainName` (`string`): максимум 200 символов
  - `IsDomainNameVerified` (`bool`)
  - `UnitId` (`string`)
  - `StudentLabId` (`string`)
  - `StudentLabProfileUrl` (`string`)
  - `StartDate` (`DateOnly`)
  - `EndDate` (`DateOnly`)
  - `CloseReason` (`InternshipCloseReason?`): опционально; связь с `InternshipCloseReason`
  - `Location` (`string`): максимум 100 символов
  - `CreatedBy` (`string`)
  - `CreationDate` (`DateTime`)
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime?`): опционально

## PreviousCompensationInfo

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/PreviousCompensationInfo.cs`
- Свойства:
  - `Amount` (`float`)
  - `Currency` (`string`)

## RelocationApprover

- Наследование: IHasCreateUpdateInfo
- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationApprover.cs`
- Свойства:
  - `Id` (`int`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `CountryId` (`string`)
  - `IsPrimary` (`bool`)
  - `ApproverOrderId` (`int?`): опционально
  - `ApproverOrder` (`RelocationApproverOrder`): связь с `RelocationApproverOrder`
  - `CreatedBy` (`string`)
  - `CreationDate` (`DateTime`)
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime?`): опционально

## RelocationApproverAssignment

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationApproverAssignment.cs`
- Свойства:
  - `Id` (`int`)
  - `RelocationPlanId` (`int`): FK на `RelocationPlan`
  - `RelocationPlan` (`RelocationPlan`): связь с `RelocationPlan`
  - `ApproverId` (`int`)
  - `Approver` (`Employee`): связь с `Employee`
  - `Date` (`DateTime`)

## RelocationApproverOrder

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationApproverOrder.cs`
- Свойства:
  - `Id` (`int`)
  - `Order` (`int`)
  - `IsNext` (`bool`)

## RelocationCaseProgress

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationCaseProgress.cs`
- Свойства:
  - `VisaProgress` (`RelocationCaseVisaProgress`): связь с `RelocationCaseVisaProgress`
  - `IsTransferBooked` (`bool`)
  - `IsAccommodationBooked` (`bool`)
  - `IsVisaGathered` (`bool`)
  - `TrpState` (`RelocationPlanTrpState?`): опционально; связь с `RelocationPlanTrpState`

## RelocationCaseStatus

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationCaseStatus.cs`
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `SourceId` (`string`)
  - `Name` (`string`)
  - `CreationDate` (`DateTime`)

## RelocationCaseVisaProgress

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationCaseVisaProgress.cs`
- Свойства:
  - `IsScheduled` (`bool`)
  - `AreDocsGathered` (`bool`)
  - `AreDocsSentToAgency` (`bool`)
  - `IsAttended` (`bool`)
  - `IsPassportCollected` (`bool`)

## RelocationPlan

- Наследование: IHasCreateUpdateInfo
- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationPlan.cs`
- Константы:
  - `CommentMaxLength` (`int`) = 5000
  - `SalaryMaxLength` (`int`) = 1000
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `SourceId` (`string`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `LocationId` (`int`)
  - `Location` (`CurrentLocation`): связь с `CurrentLocation`
  - `EmployeeDate` (`DateOnly`)
  - `EmployeeComment` (`string`)
  - `EmployeeCommentChangeDate` (`DateTime?`): опционально
  - `GmManagerId` (`int?`): опционально
  - `GmManager` (`Employee`): связь с `Employee`
  - `GmComment` (`string`)
  - `GmCommentChangeDate` (`DateTime?`): опционально
  - `IsInductionPassed` (`bool`)
  - `IsConfirmed` (`bool`)
  - `ConfirmationDate` (`DateTime?`): опционально
  - `ApproverComment` (`string`)
  - `ApproverCommentChangeDate` (`DateTime?`): опционально
  - `ApproverDate` (`DateOnly?`): опционально
  - `Salary` (`string`): максимум 1000 символов
  - `ApproverId` (`int?`): опционально
  - `Approver` (`Employee`): связь с `Employee`
  - `RelocationUnitId` (`string`)
  - `IsApproved` (`bool`)
  - `ApprovedBy` (`string`)
  - `ApprovalDate` (`DateTime?`): опционально
  - `HrManagerId` (`int?`): опционально
  - `HrManager` (`Employee`): связь с `Employee`
  - `HrManagerComment` (`string`)
  - `HrManagerCommentChangeDate` (`DateTime?`): опционально
  - `HrManagerDate` (`DateOnly?`): опционально
  - `InductionStatusChangedBy` (`string`)
  - `InductionStatusChangeDate` (`DateTime?`): опционально
  - `IsEmploymentConfirmedByEmployee` (`bool`)
  - `State` (`RelocationPlanState`): связь с `RelocationPlanState`
  - `CurrentStepId` (`RelocationStepId`): связь с `RelocationStepId`
  - `CurrentStep` (`RelocationPlanStep`): связь с `RelocationPlanStep`
  - `Steps` (`ICollection<RelocationPlanStep>`): коллекция `RelocationPlanStep`; связь с `RelocationPlanStep` (многие)
  - `StatusId` (`int`)
  - `Status` (`RelocationPlanStatus`): связь с `RelocationPlanStatus`
  - `Compensation` (`CompensationInfo`): связь с `CompensationInfo`
  - `StatusStartDate` (`DateTime`)
  - `StatusDueDate` (`DateTime?`): опционально
  - `CloseComment` (`string`)
  - `ClosedBy` (`string`)
  - `CloseDate` (`DateTime?`): опционально
  - `CreatedBy` (`string`)
  - `CreationDate` (`DateTime`)
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime?`): опционально

## RelocationPlanChange

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationPlanChange.cs`
- Свойства:
  - `Id` (`int`)
  - `RelocationPlanId` (`int`): FK на `RelocationPlan`
  - `RelocationPlan` (`RelocationPlan`): связь с `RelocationPlan`
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `Type` (`RelocationPlanChangeType`): связь с `RelocationPlanChangeType`
  - `PreviousIsInductionPassed` (`bool?`): опционально
  - `NewIsInductionPassed` (`bool?`): опционально
  - `PreviousIsConfirmed` (`bool?`): опционально
  - `NewIsConfirmed` (`bool?`): опционально
  - `PreviousDestinationId` (`int?`): опционально
  - `PreviousDestination` (`CurrentLocation`): связь с `CurrentLocation`
  - `NewDestinationId` (`int?`): опционально
  - `NewDestination` (`CurrentLocation`): связь с `CurrentLocation`
  - `PreviousIsApproved` (`bool?`): опционально
  - `NewIsApproved` (`bool?`): опционально
  - `PreviousIsEmploymentConfirmedByEmployee` (`bool?`): опционально
  - `NewIsEmploymentConfirmedByEmployee` (`bool?`): опционально
  - `PreviousStatusId` (`int?`): опционально
  - `PreviousStatus` (`RelocationPlanStatus`): связь с `RelocationPlanStatus`
  - `NewStatusId` (`int?`): опционально
  - `NewStatus` (`RelocationPlanStatus`): связь с `RelocationPlanStatus`
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime`)

## RelocationPlanStatus

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationPlanStatus.cs`
- Константы:
  - `NameMaxLength` (`int`) = 100
- Встроенные константы:
  - `BuiltIn.Induction` (`string`) = "induction"
  - `BuiltIn.EmployeeConfirmation` (`string`) = "employee_confirmation"
  - `BuiltIn.PendingApproval` (`string`) = "pending_approval"
  - `BuiltIn.RelocationApproved` (`string`) = "relocation_approved"
  - `BuiltIn.InProgress` (`string`) = "in_progress"
  - `BuiltIn.VisaDocsPreparation` (`string`) = "visa_docs_preparation"
  - `BuiltIn.WaitingEmbassyAppointment` (`string`) = "waiting_for_embassy_appointment"
  - `BuiltIn.EmbassyAppointment` (`string`) = "embassy_appointment"
  - `BuiltIn.VisaInProgress` (`string`) = "visa_in_progress"
  - `BuiltIn.VisaDone` (`string`) = "visa_done"
  - `BuiltIn.TrpDocsPreparation` (`string`) = "trp_docs_preparation"
  - `BuiltIn.TrpDocsTranslationAndLegalization` (`string`) = "trp_docs_translation_and_legalization"
  - `BuiltIn.TrpDocsSubmissionToMigrationDirectorate` (`string`) = "trp_docs_submission_to_migration_directorate"
  - `BuiltIn.TrpApplicationSubmission` (`string`) = "trp_application_submission"
  - `BuiltIn.TrpInProgress` (`string`) = "trp_in_progress"
  - `BuiltIn.TrpIdCardDocsInProgress` (`string`) = "trp_id_card_docs_in_progress"
  - `BuiltIn.EmploymentConfirmationByEmployee` (`string`) = "employment_confirmation_by_employee"
  - `BuiltIn.ReadyForEmployment` (`string`) = "ready_for_employment"
  - `BuiltIn.Rejected` (`string`) = "rejected"
  - `BuiltIn.Canceled` (`string`) = "canceled"
  - `BuiltIn.Completed` (`string`) = "completed"
  - `BuiltIn.OnHold` (`string`) = "on_hold"
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `Name` (`string`): максимум 100 символов
  - `CaseStatusId` (`int?`): опционально
  - `CaseStatus` (`RelocationCaseStatus`): связь с `RelocationCaseStatus`

## RelocationPlanStep

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationPlanStep.cs`
- Свойства:
  - `RelocationPlanId` (`int`): FK на `RelocationPlan`
  - `RelocationPlan` (`RelocationPlan`): связь с `RelocationPlan`
  - `StepId` (`RelocationStepId`): связь с `RelocationStepId`
  - `Order` (`int`)
  - `CompletedAt` (`DateTime?`): опционально
  - `IsCompletionDateHidden` (`bool`)
  - `DurationInDays` (`int?`): опционально
  - `ExpectedAt` (`DateTime?`): опционально

## Role

- Наследование: IHasCreateUpdateInfo
- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/Role.cs`
- Константы:
  - `NameMaxLength` (`int`) = 200
  - `DescriptionMaxLength` (`int`) = 500
- Встроенные константы:
  - `BuiltIn.BusinessDevelopmentManager` (`string`) = "business_development_manager"
  - `BuiltIn.MarketingManager` (`string`) = "marketing_manager"
  - `BuiltIn.InternsHrManager` (`string`) = "interns_hr_manager"
  - `BuiltIn.HrManager` (`string`) = "hr_manager"
  - `BuiltIn.Recruiter` (`string`) = "recruiter"
  - `BuiltIn.DeliveryManager` (`string`) = "delivery_manager"
  - `BuiltIn.DomainExpert` (`string`) = "domain_expert"
  - `BuiltIn.Chief` (`string`) = "chief"
  - `BuiltIn.GlobalMobilityManager` (`string`) = "global_mobility_manager"
  - `BuiltIn.ItSupport` (`string`) = "it_support"
  - `BuiltIn.Financier` (`string`) = "financier"
  - `BuiltIn.TechnicalExpert` (`string`) = "technical_expert"
  - `BuiltIn.CorporateDevelopmentManager` (`string`) = "corporate_development_manager"
  - `BuiltIn.ProjectIterationMaintainer` (`string`) = "project_iteration_maintainer"
  - `BuiltIn.WodAdmin` (`string`) = "wod_admin"
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `Name` (`string`): максимум 200 символов
  - `Description` (`string`): максимум 500 символов
  - `IsBuiltIn` (`bool`)
  - `RoleManagerId` (`string`)
  - `CreatedBy` (`string`)
  - `CreationDate` (`DateTime`)
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime?`): опционально
  - `Employees` (`ICollection<EmployeeRole>`): коллекция `EmployeeRole`; связь с `EmployeeRole` (многие)

## RoleConfiguration

- Наследование: IHasUpdateInfo
- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RoleConfiguration.cs`
- Свойства:
  - `Id` (`int`)
  - `Role` (`Role`): связь с `Role`
  - `TitleRoles` (`ICollection<RoleConfigurationTitleRole>`): коллекция `RoleConfigurationTitleRole`; связь с `RoleConfigurationTitleRole` (многие)
  - `IsAllTitleRoles` (`bool`)
  - `Units` (`ICollection<RoleConfigurationUnit>`): коллекция `RoleConfigurationUnit`; связь с `RoleConfigurationUnit` (многие)
  - `IsAllUnits` (`bool`)
  - `Employees` (`ICollection<RoleConfigurationEmployee>`): коллекция `RoleConfigurationEmployee`; связь с `RoleConfigurationEmployee` (многие)
  - `UpdatedBy` (`string`)
  - `UpdateDate` (`DateTime?`): опционально

## RoleConfigurationEmployee

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RoleConfigurationEmployee.cs`
- Свойства:
  - `RoleConfigurationId` (`int`): FK на `RoleConfiguration`
  - `RoleConfiguration` (`RoleConfiguration`): связь с `RoleConfiguration`
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`

## RoleConfigurationTitleRole

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RoleConfigurationTitleRole.cs`
- Свойства:
  - `RoleConfigurationId` (`int`): FK на `RoleConfiguration`
  - `RoleConfiguration` (`RoleConfiguration`): связь с `RoleConfiguration`
  - `TitleRoleId` (`int`): FK на `TitleRole`
  - `TitleRole` (`TitleRole`): связь с `TitleRole`

## RoleConfigurationUnit

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RoleConfigurationUnit.cs`
- Свойства:
  - `RoleConfigurationId` (`int`): FK на `RoleConfiguration`
  - `RoleConfiguration` (`RoleConfiguration`): связь с `RoleConfiguration`
  - `UnitId` (`string`)

## Seniority

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/Seniority.cs`
- Константы:
  - `MaxNameLength` (`int`) = 200
  - `Default` (`string`) = BuiltIn.Middle
- Встроенные константы:
  - `BuiltIn.Junior` (`string`) = "junior"
  - `BuiltIn.Middle` (`string`) = "middle"
  - `BuiltIn.Senior` (`string`) = "senior"
  - `BuiltIn.Lead` (`string`) = "lead"
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `Name` (`string`)
  - `IsHidden` (`bool`)
  - `Order` (`int`)

## StudentLabSyncLog

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/StudentLabSyncLog.cs`
- Свойства:
  - `Id` (`int`)
  - `SyncStartDate` (`DateTime`)
  - `SyncCompletedDate` (`DateTime`)
  - `IsSuccessful` (`bool`)
  - `IsOutdated` (`bool`)
  - `AffectedInternshipsCount` (`int`)

## SyncLog

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/SyncLog.cs`
- Свойства:
  - `Id` (`int`)
  - `Type` (`SyncType`): связь с `SyncType`
  - `SyncStartDate` (`DateTime`)
  - `SyncCompletedDate` (`DateTime`)
  - `IsSuccessful` (`bool`)
  - `IsOutdated` (`bool`)
  - `AffectedEntitiesCount` (`int`)

## TitleRole

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/TitleRole.cs`
- Константы:
  - `NameMaxLength` (`int`) = 200
- Встроенные константы:
  - `BuiltIn.Designer` (`string`) = "designer"
  - `BuiltIn.QaEngineer` (`string`) = "qa_engineer"
  - `BuiltIn.QaAutomationEngineer` (`string`) = "qa_automation_engineer"
  - `BuiltIn.SoftwareEngineer` (`string`) = "software_engineer"
  - `BuiltIn.ProjectManager` (`string`) = "project_manager"
  - `BuiltIn.BusinessAnalyst` (`string`) = "business_analyst"
  - `BuiltIn.GroupManager` (`string`) = "group_manager"
  - `BuiltIn.TeamManager` (`string`) = "team_manager"
  - `BuiltIn.DivisionManager` (`string`) = "division_manager"
  - `BuiltIn.DepartmentManager` (`string`) = "department_manager"
  - `BuiltIn.ChiefExecutiveOfficer` (`string`) = "chief_executive_officer"
  - `BuiltIn.ChiefOperationOfficer` (`string`) = "chief_operation_officer"
  - `BuiltIn.ChiefTechnologyOfficer` (`string`) = "chief_technology_officer"
  - `BuiltIn.ChiefInformationOfficer` (`string`) = "chief_information_officer"
  - `BuiltIn.ChiefFinancialOfficer` (`string`) = "chief_financial_officer"
  - `BuiltIn.HrManager` (`string`) = "hr_manager"
  - `BuiltIn.HrDirector` (`string`) = "hr_director"
  - `BuiltIn.DeliveryManager` (`string`) = "delivery_manager"
  - `BuiltIn.Director` (`string`) = "director"
  - `BuiltIn.VicePresidentBusinessDevelopment` (`string`) = "vice_president_business_development"
  - `BuiltIn.BusinessDevelopmentManager` (`string`) = "business_development_manager"
  - `BuiltIn.CorporateDevelopmentManager` (`string`) = "corporate_development_manager"
  - `BuiltIn.MarketingManager` (`string`) = "marketing_manager"
  - `BuiltIn.ToplineController` (`string`) = "topline_controller"
  - `BuiltIn.ReportingController` (`string`) = "reporting_controller"
  - `BuiltIn.FixedCostsController` (`string`) = "fixed_costs_controller"
  - `BuiltIn.HeadOfControlling` (`string`) = "head_of_controlling"
  - `BuiltIn.HeadOfDomainExpertise` (`string`) = "head_of_domain_expertise"
  - `BuiltIn.TechnicalSupportEngineerIt` (`string`) = "technical_support_engineer_it"
  - `BuiltIn.Intern` (`string`) = "intern"
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `Name` (`string`): максимум 200 символов
  - `HasSeniority` (`bool`)

## UnitInternshipsCount

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/UnitInternshipsCount.cs`
- Свойства:
  - `UnitId` (`string`)
  - `InternshipsCount` (`int`)

## WageRatePeriod

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/WageRatePeriod.cs`
- Свойства:
  - `Id` (`int`)
  - `EmployeeId` (`int`): FK на `Employee`
  - `Employee` (`Employee`): связь с `Employee`
  - `StartDate` (`DateOnly`)
  - `EndDate` (`DateOnly?`): опционально
  - `Rate` (`double`)

## Workplace

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/Workplace.cs`
- Константы:
  - `NameMaxLength` (`int`) = 200
- Свойства:
  - `Id` (`int`)
  - `ExternalId` (`string`)
  - `Name` (`string`): максимум 200 символов
  - `FullName` (`string`)
  - `SchemeUrl` (`string`)
  - `OfficeId` (`string`)
  - `CreationDate` (`DateTime`)
  - `UpdateDate` (`DateTime?`): опционально
  - `LastSyncDate` (`DateTime`)
  - `ExternalWorkplaceId` (`int`): FK на `ExternalWorkplace`
  - `ExternalWorkplace` (`ExternalWorkplace`): связь с `ExternalWorkplace`

## DeactivationReason (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/DeactivationReason.cs`
- Значения:
  - `Dismissed` = 0
  - `MaternityLeave` = 1

## DismissalRequestType (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/DismissalRequestType.cs`
- Значения:
  - `Ordinary`
  - `Relocation`
  - `ContractChange`
  - `MaternityLeave`

## EmploymentType (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/EmploymentType.cs`
- Значения:
  - `Contractor`
  - `Office`
  - `Remote`
  - `Hybrid`
  - `Internship`

## InternshipCloseReason (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/InternshipCloseReason.cs`
- Значения:
  - `Manually`
  - `AutomaticallyDueInactivity`
  - `AutomaticallyDueEmployment`

## RelocationPlanChangeType (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationPlanChangeType.cs`
- Значения:
  - `InductionPassed`
  - `Confirmed`
  - `Status`
  - `Destination`
  - `Approved`
  - `EmploymentConfirmedByEmployee`

## RelocationPlanState (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationPlanState.cs`
- Значения:
  - `Active`
  - `Completed`
  - `Cancelled`
  - `Rejected`

## RelocationPlanTrpState (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationPlanTrpState.cs`
- Значения:
  - `DocsPreparation`
  - `DocsTranslationAndLegalization`
  - `SubmissionToMigrationDirectorate`
  - `ApplicationSubmission`
  - `InProgress`
  - `IdCardDocsInProgress`

## RelocationStepId (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/RelocationStepId.cs`
- Значения:
  - `Induction`
  - `RelocationConfirmation`
  - `PendingApproval`
  - `ProcessingQueue`
  - `VisaDocsPreparation`
  - `WaitingEmbassyAppointment`
  - `EmbassyAppointment`
  - `VisaInProgress`
  - `VisaDone`
  - `TrpDocsPreparation`
  - `TrpDocsTranslationAndLegalization`
  - `TrpDocsSubmissionToMigrationDirectorate`
  - `TrpApplicationSubmission`
  - `TrpInProgress`
  - `TrpIdCardDocsInProgress`
  - `EmploymentConfirmation`
  - `EmploymentInProgress`

## SyncType (enum)

- Файл: `DreamTeam.Wod.EmployeeService.DomainModel/SyncType.cs`
- Значения:
  - `DownloadExternalWspData`
  - `LinkEmployeeWorkplaces`
  - `DownloadExternalEmploymentRequestData`
  - `LinkEmploymentRequests`
  - `DownloadExternalDismissalRequestData`
  - `LinkDismissalRequests`
  - `DownloadExternalEmployeeUnitHistory`
  - `LinkEmployeeUnitHistory`
