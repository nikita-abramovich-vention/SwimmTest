# Domain Model Overview

This document summarizes the key entities inside `DreamTeam.Wod.EmployeeService.DomainModel` and how they relate to one another. Classes follow a CQRS-friendly design where entities primarily expose properties for Entity Framework and expose small helper methods (for example `Clone`, `InitSteps`). Enumerations codify well-known states used across HR, relocation, and synchronization workflows.

## Employee Core

### Employee
- Represents a person employed by the company; implements `IHasUpdateInfo` and keeps audit fields (`CreationDate`, `UpdatedBy`, `UpdateDate`).
- Maintains Employment metadata: `EmploymentDate`, optional `DismissalDate`, `EmploymentType`, associated `Seniority`, `TitleRole`, and country/unit/organization identifiers.
- Navigation collections provide links to related aggregates: `EmploymentPeriods`, `WageRatePeriods`, `Roles`, `Workplaces`, and `CurrentLocation` changes.
- Self-referential relationships model mentorship and HR responsibility (`Mentor`, `ResponsibleHrManager`).
- `Clone()` performs a shallow copy with a defensive copy of `Roles` to avoid accidental shared mutable state.

### EmploymentPeriod
- Tracks contiguous time ranges (`StartDate`/`EndDate`) when an employee worked for an organization or internship.
- Flags internship periods via `IsInternship` and stores `OrganizationId` for reporting/history.

### EmploymentType (enum)
- Categorizes employment contract: `Contractor`, `Office`, `Remote`, `Hybrid`, `Internship`.

### EmployeeRole & Role
- `Role` acts as the master catalog (with audit metadata, built-in codes in `Role.BuiltIn`).
- `EmployeeRole` is the M:N join entity linking employees and roles.
- `Role.BuiltIn` constants define canonical role identifiers used across services (e.g., `business_development_manager`, `wod_admin`).

### TitleRole & Seniority
- `TitleRole` describes functional titles (designers, engineers, managers) and whether the title supports seniority tiers.
- `Seniority` defines progression levels (`Junior`, `Middle`, `Senior`, `Lead`) and ordering; `Default` points to `Middle`.

### WageRatePeriod
- Tracks compensation rate changes over time for an employee (`StartDate`, optional `EndDate`, numeric `Rate`).

### EmployeeWorkplace & Workplace
- `Workplace` stores internal work location descriptors synced with external systems and links to `ExternalWorkplace` records.
- `EmployeeWorkplace` links an employee to a workplace with creation audit info and optional `ExternalEmployeeWorkplace` metadata.

### CurrentLocation & EmployeeCurrentLocation*
- `CurrentLocation` catalogs available locations/offices (flags whether relocation is disabled or custom, country linkage, creation audit info).
- `EmployeeCurrentLocation` records the current assignment, while `EmployeeCurrentLocationChange` captures change history with previous/new locations and audit metadata.

### EmployeeOrganizationChange & EmployeeUnitHistory
- `EmployeeOrganizationChange` logs organization switches with audit fields.
- `EmployeeUnitHistory` stores unit assignments over time, with optional linkage to externally sourced history and a `Clone()` helper.

### EmployeeSnapshot & EmployeeSnapshotLog
- `EmployeeSnapshot` captures daily/hourly digests of employee state (seniority, title, employment type, location metadata) for analytics.
- `EmployeeSnapshotLog` stores execution metadata for snapshot generation runs (`Date`, `IsSuccessful`).

## Employment Requests & Dismissals

### EmploymentRequest & ExternalEmploymentRequest
- `ExternalEmploymentRequest` mirrors requests from source systems with metadata (status, type, names, locations, timestamps).
- `EmploymentRequest` represents the internal record tied to an employee (if matched), storing trimmed fields and referencing the external source.

### DismissalRequest & ExternalDismissalRequest
- `DismissalRequest` represents active/internal dismissal workflows and references `Employee`, `DismissalDate`, request `Type`, and its external counterpart.
- `ExternalDismissalRequest` stores raw data from the source system, including creation/update timestamps, dismissal specifics, and `SourceEmployeeId`.
- `DismissalRequestType` enumerates supported dismissal reasons (`Ordinary`, `Relocation`, `ContractChange`, `MaternityLeave`).

### DeactivationReason (enum)
- Captures causes for deactivating an employee (`Dismissed`, `MaternityLeave`).

## Relocation

### RelocationPlan
- Core aggregate controlling relocation lifecycle; implements `IHasCreateUpdateInfo`.
- Stores approvals (`GmManager`, `Approver`, `HrManager`), comments, confirmation flags, status tracking (`State`, `CurrentStepId`, `StatusStartDate`, `StatusDueDate`).
- Links to `Employee`, target `CurrentLocation`, optional compensation (`CompensationInfo`), and `RelocationPlanStatus`.
- Provides orchestration helpers:
  - `GetOrderedSteps()` sorts `Steps` by order.
  - `InitSteps()` seeds `RelocationPlanStep` entities from `CountryRelocationStep` definitions.
  - `SetStep()` advances workflow, updates completion markers, and recalculates expected dates.
  - `UpdateStepExpectedDates()` refreshes durations/expectations using provided country defaults.
  - `MatchStep()` infers the current step from `RelocationCaseProgress` and `RelocationPlanStatus` snapshots.

### RelocationPlanStep
- Child entity holding step metadata: `StepId`, `Order`, optional `DurationInDays`, expected/completion timestamps, and a flag to hide completion date.

### RelocationPlanStatus
- Catalog of statuses (name, optional `RelocationCaseStatus` link). Includes `BuiltIn` codes used for API communication.
- `From()` maps a plan state, status, and current step to a canonical status identifier and optional transition origin step.

### RelocationPlanChange & RelocationPlanChangeType
- Audit record of key state transitions (confirmation, destination change, approval, employment confirmation, status), capturing previous/new values and change metadata.
- `RelocationPlanChangeType` enumerates tracked change categories.

### RelocationPlanState & RelocationPlanTrpState (enums)
- `RelocationPlanState`: coarse-grained lifecycle (`Active`, `Completed`, `Cancelled`, `Rejected`).
- `RelocationPlanTrpState`: residence permit (TRP) workflow sub-states from document preparation through ID card processing.

### RelocationStepId (enum) & CountryRelocationStep
- `RelocationStepId` lists the ordered relocation steps from induction through employment.
- `CountryRelocationStep` defines country-specific defaults (durations/orders) and exposes `GetDefaultSteps(countryId)` returning step templates when a relocation plan is initialized.

### RelocationApprover*, RelocationApproverAssignment, RelocationApproverOrder
- `RelocationApprover` lists employees eligible to approve relocations, with country scope and optional ordering via `RelocationApproverOrder`.
- `RelocationApproverOrder` holds relative order and `IsNext` indicator for escalation.
- `RelocationApproverAssignment` snapshots the approver chosen for a particular `RelocationPlan` and the assignment date.

### RelocationCaseStatus, RelocationCaseProgress, RelocationCaseVisaProgress
- `RelocationCaseStatus` describes raw case status imports.
- `RelocationCaseProgress` and nested `RelocationCaseVisaProgress` capture fine-grained progress flags (visa booked, docs prepared, TRP state, etc.) that drive `MatchStep()` logic.

### CompensationInfo*
- `CompensationInfo` holds offer totals, currency, whether payment is in advance, and ties back to the owning `RelocationPlan`.
- `CompensationInfoDetails` and `CompensationInfoDetailsItem` break down compensation by recipient (`Child`, `Spouse`, `Employee`) with per-person amounts.
- `PreviousCompensationInfo` stores historical compensation for comparison.

## Internship & Student Lab

### Internship
- Represents an internship participant; implements `IHasCreateUpdateInfo` for auditing.
- Captures personal/contact data (name variants, communication handles), status flags (`IsActive`, `IsDomainNameVerified`), unit/lab linkage, date range, optional `InternshipCloseReason`, and a `Clone()` helper.
- Validates data lengths via constants for reuse in validation layers.

### InternshipCloseReason (enum)
- Enumerates reasons internships close (`Manually`, `AutomaticallyDueInactivity`, `AutomaticallyDueEmployment`).

### UnitInternshipsCount
- Projection reporting number of internships per unit.

### StudentLabSyncLog
- Tracks synchronization runs against Student Lab: start/end timestamps, success flag, obsolescence flag, and number of affected internships.

## Synchronization Logs

### SyncLog & SyncType
- `SyncLog` stores metadata for generic synchronization jobs (type, timestamps, success/outdated flags, affected entity count).
- `SyncType` enumerates supported sync workflows (downloading/linking external data for workplaces, employment requests, dismissal requests, unit history).

## External Source Mirrors

### ExternalEmployeeUnitHistory, ExternalEmployeeWorkplace, ExternalWorkplace
- Mirror records imported from external HR systems; maintain source identifiers, timestamps, and optional linkage to internal entities.
- Provide traceability and deferred reconciliation between internal and external data.

### Employment & Dismissal External Mirrors
- `ExternalEmploymentRequest` and `ExternalDismissalRequest` hold original data needed for reconciliation, unique constraints, and auditing.

## Supporting Types

### EmployeeCurrentLocationChange, EmployeeOrganizationChange
- Simple audit types capturing previous/new values and who performed the change.

### RelocationPlanStatus Built-in Codes
- `RelocationPlanStatus.BuiltIn` exposes string constants allowing upstream/downstream systems to exchange status identifiers without relying on numeric IDs.

### RoleConfiguration*
- `RoleConfiguration` defines scoping rules for roles: by title roles (`RoleConfigurationTitleRole` join), units (`RoleConfigurationUnit`), or specific employees (`RoleConfigurationEmployee`).
- Derived properties `IsAllTitleRoles` / `IsAllUnits` help evaluate the configuration semantics.

### Employee & Internship Clone Helpers
- Several aggregates (`Employee`, `EmployeeUnitHistory`, `Internship`, `RelocationPlan`, `DismissalRequest`) expose `Clone()` to produce detached copies when mutating state for change tracking or comparison scenarios.

## Process Flags & Enumerations

- `DeactivationReason`, `DismissalRequestType`, `EmploymentType`, `InternshipCloseReason`, `RelocationPlanState`, `RelocationPlanTrpState`, `RelocationStepId`, and `SyncType` codify state machines across the HR domain.
- Having centralized enums ensures validation consistency across services and data stores.

